package seng202;

public class Position {
    public double lat;
    public double lng;

    public Position(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }
}
